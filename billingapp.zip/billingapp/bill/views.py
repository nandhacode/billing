from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from .models import Items
import json

# Create your views here.
def index(request):
    products = Items.objects.all()
    return render(request, 'index.html')

def bill(request):
    products = request.GET['s_products']
    quantitys = request.GET['s_quantitys']
    email = request.GET['email']

    case_500 = request.GET['500']
    case_100 = request.GET['100']
    case_50 = request.GET['50']
    case_20 = request.GET['20']
    case_10 = request.GET['10']
    case_5 = request.GET['5']
    case_2 = request.GET['2']
    case_1 = request.GET['1']

    case_customer = request.GET['case_customer']

    l_products = []
    l_quantitys = []

    l_products = products.split(',')
    l_products = [int(item) for item in l_products] 

    l_quantitys = quantitys.split(',')
    l_quantitys = [int(item) for item in l_quantitys] 
    
    products = Items.objects.filter(product_id__in=l_products)

    list_items = []

    total_price_without_tax = total_tax = net_price_items = round_down_price = balance_payable = 0
    
    for product, quantity in zip(products,l_quantitys):
        single_items = {}
        single_items['product_id'] = product.product_id
        single_items['available_stock'] = product.available_stock
        single_items['name'] = product.name
        single_items['price'] = product.price
        single_items['quantity'] = quantity
        single_items['purchase_price'] = product.price * quantity
        single_items['tax'] = product.tax
        single_items['tax_price'] = (product.price * quantity) * product.tax / 100
        single_items['total_price'] = (product.price * quantity) + ((product.price * quantity) * product.tax / 100)

        list_items.append(single_items)

        total_price_without_tax += product.price * quantity
        total_tax += (product.price * quantity) * product.tax / 100 
        net_price_items += (product.price * quantity) + ((product.price * quantity) * product.tax / 100)
        round_down_price = round(net_price_items)
    
    balance_payable = int(case_customer) - int(round_down_price)
        
    bill_section = {
        'total_price_without_tax': total_price_without_tax,
        'total_tax': total_tax,
        'net_price_items': net_price_items,
        'round_down_price': round_down_price,
        'balance_payable': balance_payable
    }

    case_list = []
    if(case_500):
        case_list.append({'name':'500','count':case_500})
    if(case_100):
        case_list.append({'name':'100','count':case_100})
    if(case_50):
        case_list.append({'name':'50','count':case_50})
    if(case_20):
        case_list.append({'name':'20','count':case_20})
    if(case_10):
        case_list.append({'name':'10','count':case_10})
    if(case_5):
        case_list.append({'name':'5','count':case_5})
    if(case_2):
        case_list.append({'name':'2','count':case_2})
    if(case_1):
        case_list.append({'name':'1','count':case_1})
    

    return render(request, 'bill.html', {'email':email, 'products':list_items, 'bill_section':bill_section, 'cases':case_list})