from django.db import models

# Create your models here.
class Items(models.Model):
    name = models.CharField(max_length=100)
    product_id = models.IntegerField()
    available_stock = models.IntegerField()
    price = models.FloatField()
    tax = models.FloatField()
    create_at = models.DateTimeField(auto_now_add=True)
    update_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
