from typing import Any
from bill.models import Items
from django.core.management.base import BaseCommand

class Command(BaseCommand):

    def handle(self, *args, **options):
        
        names = ['Apple','Mango','Orange']
        product_ids = [1,2,3]
        stocks = [10,20,5]
        prices = [100,80,120]
        taxs = [10,8.5,15]

        for name, product_id, stock, price, tax in zip(names,product_ids,stocks,prices,taxs):
            Items.objects.create(name=name,product_id=product_id,available_stock=stock,price=price,tax=tax)

        self.stdout.write(self.style.SUCCESS("Data successfully inserted!!!"))